package Views;

import Dao.UserDao;
import Model.User;
import Service.GenerateOTP;
import Service.SendOTPService;
import Service.UserService;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.Buffer;
import java.sql.SQLException;
import java.sql.SQLOutput;
import java.util.Scanner;

public class Welcome {
    public void welcomeScreen(){
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        System.out.println("Welcome To The Application");
        System.out.println("Press 1 to Login as User");
        System.out.println("Press 2 to signup");
        System.out.println("Press 0 to exit");
        int choise = 0;

        try{
            choise = Integer.parseInt(br.readLine());
        }
        catch (IOException ex){
            ex.printStackTrace();
        }

            switch ((choise)){
            case 1 -> login();
            case 2 -> signUp();
            case 0 -> System.exit(0);
            }


     }
    // Making it so user can login
    private void login(){
        System.out.println("Enter your Email");

        Scanner sc = new Scanner(System.in);
        String email = sc.nextLine();
        try{
            if(UserDao.Isexist(email)){
                String genOTP = GenerateOTP.getOTP();
                SendOTPService.sendOTP(email,genOTP);
                System.out.println("Enter the OTP ");
                String otp = sc.nextLine();
                if(otp.equals(genOTP)){
                    System.out.println("!! Welcome !!");
                    new UserView(email).home();

                }else{
                    System.out.println("Wrong OTP");
                }
            }else{
                System.out.println("User Not Exist");
            }
        }catch (SQLException ex){
            ex.printStackTrace();
        }
    }

    private void signUp(){
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter Your Name");
        String name = sc.nextLine();
        System.out.println("Enter Your Email");
        String email = sc.nextLine();
        /* We should check that user already exist or not

         do her after som time

        */
        String genOTP = GenerateOTP.getOTP();
        SendOTPService.sendOTP(email,genOTP);
        System.out.println("Enter the OTP ");
        String otp = sc.nextLine();
        if(otp.equals(genOTP)){
            User user = new User(name,email);
            int response = UserService.saveUser(user);
            switch (response){
                case 0 -> System.out.println("User Registerd");
                case 1 -> System.out.println("User Already Exixt");

            }

        }else{
            System.out.println("Wrong OTP");
        }

    }
}
