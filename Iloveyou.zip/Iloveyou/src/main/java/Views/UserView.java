package Views;

import Dao.DataDao;
import Model.Data;

import java.io.File;
import java.io.IOException;
import java.sql.SQLException;
import java.util.List;
import java.util.Scanner;

public class UserView {
private String email;

     UserView(String email) {
         this.email = email;
    }

    public void home() throws SQLException {
    do{
        System.out.println("Welcome "+this.email );
        System.out.println("Press 1 to show hidden Files");
        System.out.println("Press 2 To Hide new Files");
        System.out.println("Press 3 to Unhide a File");
        System.out.println("Press 0 to Exit");
        Scanner sc = new Scanner(System.in);
        int ch = Integer.parseInt(sc.nextLine());
        switch (ch){
            case 1 -> {
                try{
                List<Data> files = DataDao.getAllFiles(this.email);
                    System.out.println("ID - File Name");
                    for(Data file : files){
                        System.out.println(file.getId() +" - "+file.getFilename());
                    }
            }catch (SQLException ex){
                    ex.printStackTrace();
                }
            }
            case 2 -> {
                System.out.println("Enter File path ");
                String path = sc.nextLine();
                File f = new File(path);
                Data file = new Data(0,f.getName(),path,this.email);
                try {
                    DataDao.hideFiles(file);
                } catch (IOException e) {
                    e.printStackTrace();
                }catch (SQLException e){
                    e.printStackTrace();
                }
            }
            case 3 ->{
                List<Data> files ;
                try {
                    files = DataDao.getAllFiles(this.email);

                    System.out.println("ID - File Name");
                    for (Data file : files) {
                        System.out.println(file.getId() + " - " + file.getFilename());
                    }
                    System.out.println("Enter the Id of File to Unhide");
                    int id = Integer.parseInt(sc.nextLine());
                    boolean isvalidid = false;
                    for (Data file : files) {
                        if (file.getId() == id) {
                            isvalidid = true;
                            break;
                        }
                    }
                    if (isvalidid) {
                        DataDao.unhide(id);
                    } else {
                        System.out.println("Wrong id");
                    }
                }catch (SQLException e){
                    e.printStackTrace();
                }catch (IOException e){
                    e.printStackTrace();
                }

            }
            case 0 -> {
                System.exit(0);
            }

        }
    }while(true);
    }


}
