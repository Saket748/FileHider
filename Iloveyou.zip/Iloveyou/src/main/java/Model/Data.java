package Model;

public class Data {
    private int id;
    private String filename;
    private String email;
    private String path;

    public Data(int id, String filename, String email, String path) {
        this.id = id;
        this.filename = filename;
        this.email = email;
        this.path = path;
    }

    public Data(int id, String filename, String path) {
        this.id = id;
        this.filename = filename;
        this.path = path;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getFilename() {
        return filename;
    }

    public void setFilename(String filename) {
        this.filename = filename;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPath() {
        return path;
    }

    public void setPath(String path) {
        this.path = path;
    }
}
