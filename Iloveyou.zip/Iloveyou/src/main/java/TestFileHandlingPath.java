import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;


public class TestFileHandlingPath {
    public static void main(String[] args) throws IOException {
//        File obj = new File("/home/saket/baba");
//        obj.mkdir();//create folder

        File fl = new File("/home/saket/l");

        System.out.println(fl.createNewFile());// Creat file

        FileWriter fw = new FileWriter(fl);// obj2 write the strings(data) in file
        fw.write("aur haal chaal");// data enter
        fw.close();// file close

//        Scanner sc = new Scanner(fl);// read data from differ files.txt
//        while (sc.hasNext()){
//            String data = sc.nextLine();
//            System.out.println(data);
//        }

//        FileReader flr = new FileReader(fl);// file raeder se reead karna start
//        int i =0;
//        while((i=flr.read()) != -1){
//            System.out.print((char)i); // print the data
//        }

    }
}
