package database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.text.CompactNumberFormat;

public class MyConnection {
    public static Connection connection = null;
    public static Connection getConnection(){
        try {

            connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/Iloveyou?useSSl=false","Saket-yadav","example-password");
            Class.forName("com.mysql.cj.jdbc.Driver");

        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        }
        System.out.println("Connection ho gaya BC");
        return  connection;
    }
    public static  void closeConnection(){
        if(connection!=null){
            try{
                connection.close();
            }catch (SQLException ex){
                ex.printStackTrace();
            }
        }
    }

    public static void main(String[] args) {
        MyConnection.getConnection();
    }
}
