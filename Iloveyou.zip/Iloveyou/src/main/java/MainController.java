import Views.Welcome;

public class MainController {
    public static void main(String[] args) {
        Welcome w = new Welcome();
        do{

            w.welcomeScreen();

        }while(true);
    }
}
